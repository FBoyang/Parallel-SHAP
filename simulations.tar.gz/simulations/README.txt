n: sample size
m: feature size

simluation 1: 
Linear relationship
The first 30 features are causal
n: {5000}
m: {50, 100, 500, 1000}


simulation 2: 
Nonlinear relationship (RBF kernel)
The first 30 feautres are causal 
n: {5000}
m: {10, 100, 500, 1000}




